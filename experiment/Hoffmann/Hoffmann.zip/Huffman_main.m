freq=[0.4 0.3 0.1 0.1 0.08 0.02]
[code, Avg_len]=Huffman(freq)
